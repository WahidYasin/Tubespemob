// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'towing3_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<Towing3Record> _$towing3RecordSerializer =
    new _$Towing3RecordSerializer();

class _$Towing3RecordSerializer implements StructuredSerializer<Towing3Record> {
  @override
  final Iterable<Type> types = const [Towing3Record, _$Towing3Record];
  @override
  final String wireName = 'Towing3Record';

  @override
  Iterable<Object?> serialize(Serializers serializers, Towing3Record object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object?>[];
    Object? value;
    value = object.nama;
    if (value != null) {
      result
        ..add('nama')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.email;
    if (value != null) {
      result
        ..add('email')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.phone;
    if (value != null) {
      result
        ..add('phone')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.alamat;
    if (value != null) {
      result
        ..add('alamat')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.tanggal;
    if (value != null) {
      result
        ..add('tanggal')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.ffRef;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    return result;
  }

  @override
  Towing3Record deserialize(
      Serializers serializers, Iterable<Object?> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new Towing3RecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current! as String;
      iterator.moveNext();
      final Object? value = iterator.current;
      switch (key) {
        case 'nama':
          result.nama = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'email':
          result.email = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'phone':
          result.phone = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'alamat':
          result.alamat = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'tanggal':
          result.tanggal = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'Document__Reference__Field':
          result.ffRef = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
      }
    }

    return result.build();
  }
}

class _$Towing3Record extends Towing3Record {
  @override
  final String? nama;
  @override
  final String? email;
  @override
  final String? phone;
  @override
  final String? alamat;
  @override
  final DateTime? tanggal;
  @override
  final DocumentReference<Object?>? ffRef;

  factory _$Towing3Record([void Function(Towing3RecordBuilder)? updates]) =>
      (new Towing3RecordBuilder()..update(updates))._build();

  _$Towing3Record._(
      {this.nama,
      this.email,
      this.phone,
      this.alamat,
      this.tanggal,
      this.ffRef})
      : super._();

  @override
  Towing3Record rebuild(void Function(Towing3RecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  Towing3RecordBuilder toBuilder() => new Towing3RecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is Towing3Record &&
        nama == other.nama &&
        email == other.email &&
        phone == other.phone &&
        alamat == other.alamat &&
        tanggal == other.tanggal &&
        ffRef == other.ffRef;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc(
            $jc($jc($jc($jc(0, nama.hashCode), email.hashCode), phone.hashCode),
                alamat.hashCode),
            tanggal.hashCode),
        ffRef.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper(r'Towing3Record')
          ..add('nama', nama)
          ..add('email', email)
          ..add('phone', phone)
          ..add('alamat', alamat)
          ..add('tanggal', tanggal)
          ..add('ffRef', ffRef))
        .toString();
  }
}

class Towing3RecordBuilder
    implements Builder<Towing3Record, Towing3RecordBuilder> {
  _$Towing3Record? _$v;

  String? _nama;
  String? get nama => _$this._nama;
  set nama(String? nama) => _$this._nama = nama;

  String? _email;
  String? get email => _$this._email;
  set email(String? email) => _$this._email = email;

  String? _phone;
  String? get phone => _$this._phone;
  set phone(String? phone) => _$this._phone = phone;

  String? _alamat;
  String? get alamat => _$this._alamat;
  set alamat(String? alamat) => _$this._alamat = alamat;

  DateTime? _tanggal;
  DateTime? get tanggal => _$this._tanggal;
  set tanggal(DateTime? tanggal) => _$this._tanggal = tanggal;

  DocumentReference<Object?>? _ffRef;
  DocumentReference<Object?>? get ffRef => _$this._ffRef;
  set ffRef(DocumentReference<Object?>? ffRef) => _$this._ffRef = ffRef;

  Towing3RecordBuilder() {
    Towing3Record._initializeBuilder(this);
  }

  Towing3RecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _nama = $v.nama;
      _email = $v.email;
      _phone = $v.phone;
      _alamat = $v.alamat;
      _tanggal = $v.tanggal;
      _ffRef = $v.ffRef;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(Towing3Record other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$Towing3Record;
  }

  @override
  void update(void Function(Towing3RecordBuilder)? updates) {
    if (updates != null) updates(this);
  }

  @override
  Towing3Record build() => _build();

  _$Towing3Record _build() {
    final _$result = _$v ??
        new _$Towing3Record._(
            nama: nama,
            email: email,
            phone: phone,
            alamat: alamat,
            tanggal: tanggal,
            ffRef: ffRef);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,no_leading_underscores_for_local_identifiers,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new,unnecessary_lambdas
