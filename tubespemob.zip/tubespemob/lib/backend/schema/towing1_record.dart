import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'towing1_record.g.dart';

abstract class Towing1Record
    implements Built<Towing1Record, Towing1RecordBuilder> {
  static Serializer<Towing1Record> get serializer => _$towing1RecordSerializer;

  String? get nama;

  String? get email;

  String? get phone;

  String? get alamat;

  DateTime? get tanggal;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(Towing1RecordBuilder builder) => builder
    ..nama = ''
    ..email = ''
    ..phone = ''
    ..alamat = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('towing1');

  static Stream<Towing1Record> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<Towing1Record> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  Towing1Record._();
  factory Towing1Record([void Function(Towing1RecordBuilder) updates]) =
      _$Towing1Record;

  static Towing1Record getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createTowing1RecordData({
  String? nama,
  String? email,
  String? phone,
  String? alamat,
  DateTime? tanggal,
}) {
  final firestoreData = serializers.toFirestore(
    Towing1Record.serializer,
    Towing1Record(
      (t) => t
        ..nama = nama
        ..email = email
        ..phone = phone
        ..alamat = alamat
        ..tanggal = tanggal,
    ),
  );

  return firestoreData;
}
