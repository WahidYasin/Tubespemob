import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'towing2_record.g.dart';

abstract class Towing2Record
    implements Built<Towing2Record, Towing2RecordBuilder> {
  static Serializer<Towing2Record> get serializer => _$towing2RecordSerializer;

  String? get nama;

  String? get email;

  String? get phone;

  String? get alamat;

  DateTime? get tanggal;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(Towing2RecordBuilder builder) => builder
    ..nama = ''
    ..email = ''
    ..phone = ''
    ..alamat = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('towing2');

  static Stream<Towing2Record> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<Towing2Record> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  Towing2Record._();
  factory Towing2Record([void Function(Towing2RecordBuilder) updates]) =
      _$Towing2Record;

  static Towing2Record getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createTowing2RecordData({
  String? nama,
  String? email,
  String? phone,
  String? alamat,
  DateTime? tanggal,
}) {
  final firestoreData = serializers.toFirestore(
    Towing2Record.serializer,
    Towing2Record(
      (t) => t
        ..nama = nama
        ..email = email
        ..phone = phone
        ..alamat = alamat
        ..tanggal = tanggal,
    ),
  );

  return firestoreData;
}
