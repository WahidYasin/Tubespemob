import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'towing3_record.g.dart';

abstract class Towing3Record
    implements Built<Towing3Record, Towing3RecordBuilder> {
  static Serializer<Towing3Record> get serializer => _$towing3RecordSerializer;

  String? get nama;

  String? get email;

  String? get phone;

  String? get alamat;

  DateTime? get tanggal;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(Towing3RecordBuilder builder) => builder
    ..nama = ''
    ..email = ''
    ..phone = ''
    ..alamat = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('towing3');

  static Stream<Towing3Record> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<Towing3Record> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  Towing3Record._();
  factory Towing3Record([void Function(Towing3RecordBuilder) updates]) =
      _$Towing3Record;

  static Towing3Record getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createTowing3RecordData({
  String? nama,
  String? email,
  String? phone,
  String? alamat,
  DateTime? tanggal,
}) {
  final firestoreData = serializers.toFirestore(
    Towing3Record.serializer,
    Towing3Record(
      (t) => t
        ..nama = nama
        ..email = email
        ..phone = phone
        ..alamat = alamat
        ..tanggal = tanggal,
    ),
  );

  return firestoreData;
}
