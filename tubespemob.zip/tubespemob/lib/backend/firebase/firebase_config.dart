import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyD-2mQWwTL04y2qmFBJxcCtE-LHdgx5V1k",
            authDomain: "tubespemob24.firebaseapp.com",
            projectId: "tubespemob24",
            storageBucket: "tubespemob24.appspot.com",
            messagingSenderId: "306381602626",
            appId: "1:306381602626:web:b1b7627902605b6bd212db"));
  } else {
    await Firebase.initializeApp();
  }
}
